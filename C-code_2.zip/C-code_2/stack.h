/* FILE stack.h */

#include "_imports/deffs.h"
#include "_imports/event.h"

EVENT *Header_stack(void);
