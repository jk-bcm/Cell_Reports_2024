typedef struct 
{
  short ch_x;
  short ch_y;
} CROSS_HAIR;

CROSS_HAIR ch;					/* Holds cursor position*/

char cross_hair(CROSS_HAIR *chp);			/* cross.c	*/
void mark_point(CROSS_HAIR where, int n_id, char a_id);	/* digi.c	*/
