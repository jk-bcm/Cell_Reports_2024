/* FILE help.c */
	/* PRINT menus	*/
#include <stdio.h>
#include "defs.h"
#define print(s)    fputs(s,stderr)		/* No arguments!	*/
#define print1(s,a) fprintf(stderr,s,a)
#define print2(s,a,b) fprintf(stderr,s,a,b)
/* ********************************************************************	*/

/* FUNCTION HelpMenu */
	 /* Print help menus	*/
void HelpMenu(char c) {
	switch(c) {
   	   case '?':
   		HelpGeneral();				/* General help stuff	*/
		return;
   	   default:
		print("What?");
	   }
	return;
	}
/* ********************************************************************	*/

/* FUNCTION HelpGeneral */
	/* REWRITE:  Query "hardcopy?" then give extensive help.
		Help given == help given by "help r", for example.
		So: DON'T WRITE A MASS HELP!  write 1-4 liners, 
		and make HelpGeneral call them all!	*/
void HelpGeneral(void) {
print("\n\n\
COMPUTATION\n\
Filter		f,F\t\
Vergence	v,V\t\
dx/dt		i,I\n\
Offset		o,O^o alt-o\t\
Diverge (of 2)  d,D\t\
   (from 0)	z,Z\n\
Begin deletion	b,B\t\
Subtract	-,_\t\
Multiply	M\n\
Average		a\t\
Shift		>\t\
Elim saccade	E,e\n\
Peak detect	p,P\t\
Halve (rectify)	h,H,K\t\
Saccade	detect	S,s\n\
Automode	A\t\
Normalize      ^N\t\
Transfer	C\t\
Length		L\
\n\
GRAPHICS\n\
graph		G,g\t\
 units		u,U\t\
Title		T\n\
erase		x,X\t\
print		^P\t\
screen select	1,2,3\n\
\n\
DATA\n\
move		m\t\
list		l\t\
remove		r\n\
read/write	R,W\t\
rename		k\t\
next		n,N\n\
\n\
MISC\n\
Quit		Q\t\
Help		?\t\
Digipad		%\n\
Paint		@\n\
Macro		*\t\
CurrentStack	&\t\
Close all	^\n\
Echo line	!\n\
");
return;
}
/* ********************************************************************	*/
