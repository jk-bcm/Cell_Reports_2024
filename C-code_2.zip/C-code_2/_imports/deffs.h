/* FILE deffs.h */

#define NEW_TOUCH 01			/* For head.h, head.flag	*/
#define DELTA_WRITE 02			/* analog data			*/

#define int short

typedef struct {				/* Available to all!	*/
	int  time;
	int  type;
	int  one;
	int  two;
	int  three;
	} EVENT;

/* TOUCH or ARMDATA: used by switch,file,graph */

typedef struct {			/* grab 2000 (reach version 1)	*/
	unsigned char touch;
	int h;
	int v;
	int time;
	} TOUCH;

	/* grab 2003: (reach version 2 & 10275) uses just one int	*/

typedef struct {			/* grab 2004: reach version 3	*/
	unsigned int time;		/* ONLY setup 3, ~1/04 - 5/04	*/
	int h;				/*  (early train data for Wel)	*/
	int v;
	} ARMDATA_OLD;

typedef struct {			/* grab 2004: reach version 3	*/
	unsigned int time;
	int h;
	int v;
	int h_width;
	int v_width;
	} ARMDATA;

typedef struct {
	int value;
	int time;
	} BUTTONS;

#  define	TIME		0	/* For StackExtract 'which'	*/
#  define	ONE		1
#  define	TWO		2
#  define	THREE		3
#  define	MINOR		1	/* Archaic form: should remove!	*/
#  define	VALUE		2
#  define	EXTRA		3

#define SPECIAL_FORMAT_STRING	""

#undef int
