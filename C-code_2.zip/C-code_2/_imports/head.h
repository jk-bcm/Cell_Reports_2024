/* FILE head.h */
     /* Header declaration */

#define int short
struct HEADER {
	  char tag[8];				/* Bytes 0-7	*/
	  char stackname[18];			/* Bytes 8-25	*/
	  int  viewing_distance;		/* Bytes 26-27	*/
	  int  setup;				/* Bytes 28-29	*/
	  int  touch_count2;			/* Bytes 30-31	*/
	  int  stacknumber;			/* Bytes 32-33	*/
	  int  spike_count;			/* Bytes 34-35	*/
	  int  frame_count;			/* Bytes 36-37	*/
	  int  touch_count1;			/* Bytes 38-39	*/
	  int  channel_count;			/* Bytes 40-41	*/
	  int  column_number;			/* Bytes 42-43	*/
	  int  ms_per_frame;			/* Bytes 44-45	*/
	  int  sync_count;			/* Bytes 46-47	*/
	  struct HEAD_ID {			/* Bytes 48-61  */
	     char monk[4];
	     int spike_count3;			/* Out of place!*/
	     int spike_count4;			/* Out of place!*/
	     int unit;
	     int run;
	     /* int trial */			/* BELONGS HERE!*/
	     int version;
	     } id;
	  struct HEAD_TIME {			/* Bytes 62-67	*/
	     int hour;
	     int minute;
	     int second;
	     /* int time_hsecond; */		/* BELONGS HERE!*/
	     } time;
	  struct HEAD_DATE {			/* Bytes 68-73	*/
	     int year;
	     int month;
	     int day;
	     } date;
	  int chair_at;				/* Bytes 74-75	*/
	  int trial;				/* Bytes 76-77	*/
	  int run_status;			/* Bytes 78-79	*/
	  int relax_window;			/* Bytes 80-81	*/
	  int err_type;				/* Bytes 82-83	*/
	  int extra_time_on_err;		/* Bytes 84-85	*/
	  int relax_windows[5];			/* Bytes 86-95	*/
	  int punishtimes[6];			/* Bytes 96-107	*/
	  int calib_file;			/* Bytes 108-109*/
	  int consecutive_successes;		/* Bytes 110-111*/
	  int button_count;			/* Byters 112-113*/
	  int time_hsecond;			/* Bytes 114-115*/
	  int touch_width;			/* Bytes 116-117*/
	  int flags;				/* Bytes 118-119*/
	  int h_touch_bound;			/* Bytes 120-121*/
	  int v_touch_bound;			/* Bytes 122-123*/
	  int multi_count;			/* Bytes 124-125*/
	  int event_count;			/* Bytes 126-127*/
	  } h;

EVENT header_stack[MAX_EVENTS+2];		/* +2: insurance	*/
#undef int
