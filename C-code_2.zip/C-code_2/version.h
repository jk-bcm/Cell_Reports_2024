/* FILE version.h */

#define MINIMUM_ISI		0.9	/* Else spike is glitch (5.5 ms)*/
					/* was 0.9;chg'd 2015-03-31 to 4*/
					/* changed back to 0.9 for harry*/
/* Loading options */			/* Mutually exclusive:		*/
#define NORMAL_UNIT_ENCODING 	1	/* Straightforward 1/interval	*/
#define LISBERGER_UNIT_ENCODING	0	/* Delay by ~1 ISI		*/
