/* FILE eyecal.h */
     /* Lookup tables for load_data()	*/

#if (DOUBLE_AD_VALUES)
#define LOOKUP_SIZE		8192
#else
#define LOOKUP_SIZE		4096
#endif

int OD_H_Lookup[LOOKUP_SIZE+1];
int OS_H_Lookup[LOOKUP_SIZE+1];

int OD_Eyecal, OS_Eyecal;	/* Flags, set by eyecal, used by load	*/

				/* Index: offset by LookupSize/2    */
# define INDEXtoAD(index)	((index)-(LOOKUP_SIZE>>1))
# define ADtoINDEX(ad)		((ad)  + (LOOKUP_SIZE>>1))
/* ********************************************************************	*/
