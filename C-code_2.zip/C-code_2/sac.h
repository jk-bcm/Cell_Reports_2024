/* FILE sac.h	*/
     /*	FindSaccade() fills struct if sac is found (else holds garbage)	*/

extern struct {
  int begin;
  int peak;
  int end;
} SaccadeData;
/* ********************************************************************	*/
