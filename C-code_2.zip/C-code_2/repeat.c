/* FILE repeat.c */
     /* Repeat_macro:  repeat a single command on many registers */
#include <ctype.h>					/* isdigit()	*/
#include <stdio.h>					/* fprintf()	*/
#include <stdlib.h>					/* atoi()	*/

       				/* These 3 'externed' to lib.c:inputs()	*/
int    RepeatFlag = 0;		/* inputs():skip stdin; also ChooseReg()*/
int    RepeatStringNumber;	/* Tell inputs() which string to get	*/
char   RepeatString[5][255];	/* Strings for inputs() to retrieve	*/


/* FUNCTION Repeat_macro */
void Repeat_macro(char *RepCmdLine) {
   int From, To;
   char Command[255];
   char SaveCmd;
   int i;
   extern void inputs(char *say, char *fetch);
   
   if (*RepCmdLine == 0) {
      inputs("Repeat on (1st reg) :  ", RepCmdLine);
      From = atoi(RepCmdLine);
      inputs("          (final)   :  ", RepCmdLine);
      To = atoi(RepCmdLine);
   } else {
      while (! isdigit(*(RepCmdLine)))
         ++RepCmdLine;				/* Chew space before	*/
      From = atoi(RepCmdLine);			/* Grab 'From'		*/
      while (isdigit(*(++RepCmdLine))) ;	/* Chew 'From'		*/
      To = atoi(RepCmdLine);			/* Grab ' To'		*/	
      }
   
   inputs(" One letter command :  ", Command);
   for (i=0; i<5; i++) {
      RepeatString[i][0] = '\0';
      inputs("Next parameter:", &(RepeatString[i][0]));
      if (RepeatString[i][0] == 0)
         break;

      }
   while (++i < 5)
      RepeatString[i][0] = '\0';
   SaveCmd = Command[0];
   
   RepeatFlag = 1;
   while (From <= To) {
      extern void DoCommand(char *CmdLine);
      RepeatStringNumber = 0;
      sprintf(Command, "%c%d\0", SaveCmd, From++);
      DoCommand(Command);
      }
   RepeatFlag = 0;
   }
