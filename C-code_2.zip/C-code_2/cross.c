/* FUNCTION cross_hair */
	 /* Purina mouse chow: EMULATION! */
#include "cross.h"				/* Structure CROSS_HAIR	*/
#include "defs.h"				/* For status		*/
#include "termdef.h"				/* GIN			*/

/* FUNCTION cross_hair */

char cross_hair(CROSS_HAIR *chp) {
	char buf[20];

	if (Status & COMMAND_MODE) {	/* Don't look for mouse		*/
	   fgets(buf,20,stdin);		/* Loses all but first char	*/
	   *strchr(buf, '\n') = 0;
	} else {
	   inputs("Enter char, x-coord, y-coord as string, e.g. b6,4:  ", buf);
	   chp->ch_x = atoi(buf+1);
	   chp->ch_y = atoi( strchr(buf+2, ',')+1 );
	   } 
	return(buf[0]);
	}
