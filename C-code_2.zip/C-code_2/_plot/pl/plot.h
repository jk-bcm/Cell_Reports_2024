#ifndef _pl_h
#define _pl_h

#include <stdarg.h>
#include <stdio.h>

int devicePL	      (va_list *args);

int openplPL          (void);
int closeplPL         (void);
int flushplPL         (void);
int spacePL           (int x0, int y0, int x1, int y1);
int colorPL           (int red, int green, int blue);
int bkgndPL           (int red, int green, int blue);
int linemodPL         (char *s);
int linewidthPL       (int);
int fillPL            (int level);
int fontnamePL        (char *s);
int fontsizePL        (int size);
int rotatePL          (int w, int h, int angle);
int erasePL           (void);
int labelPL           (char *s);
int alabelPL          (int x_justify, int y_justify, char *s);
int arcPL             (int xc, int yc, int x0, int y0, int x1, int y1);
int boxPL             (int x0, int y0, int x1, int y1);
int circlePL          (int x, int y, int r);
int contPL            (int x, float y);
int dotPL             (int x, int y, int dx, int n, char *pattern);
int pointPL           (int x, int y);
int linePL            (int x0, int y0, int x1, int y1);
int movePL            (int x, float y);

/*
 * Output file.
 */
extern FILE *outfilePL;

/*
 * Write binary value.
 */

void putshort (short);

/*
 * Byte order global.
 */
extern int output_high_byte_first;

/*
 * Defines for the user.
 */
#define BigEndian      1
#define LittleEndian  -1
#define NativeEndian   0

#endif
