#ifndef _psplot_defines_
#define _psplot_defines_ 1

#include <stdarg.h>
#include <stdio.h>

int deviceID	     (va_list *args);

int openplID          (void);
int closeplID         (void);
int flushplID	      (void);
int spaceID           (int x0, int y0, int x1, int y1);
int colorID           (int red, int green, int blue);
int bkgndID           (int red, int green, int blue);
int linemodID         (char *s);
int linewidthID       (int);
int fillID            (int level);
int fontnameID        (char *s);
int fontsizeID        (int size);
int rotateID          (int w, int h, int angle);
int eraseID           (void);
int labelID           (char *s);
int alabelID          (int x_justify, int y_justify, char *s);
int arcID             (int xc, int yc, int x0, int y0, int x1, int y1);
int boxID             (int x0, int y0, int x1, int y1);
int circleID          (int x, int y, int r);
int contID            (int x, float y);
int dotID             (int x, int y, int dx, int n, char *pattern);
int pointID           (int x, int y);
int lineID            (int x0, int y0, int x1, int y1);
int moveID            (int x, float y);
#endif
