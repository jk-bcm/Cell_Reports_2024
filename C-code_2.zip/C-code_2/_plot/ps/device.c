#include	"plot.h"
#include	"../plot.h"

/*
 * Global initialization of function povoiders *
 */

int (* openplP)		(void)			= openplID;   
int (* closeplP)	(void)			= closeplID;  
int (* flushplP)	(void)			= flushplID;
int (* spaceP)		(int, int, int, int)	= spaceID;    
int (* colorP)		(int, int, int)		= colorID;   
int (* bkgndP)		(int, int, int)		= bkgndID;
int (* linemodP)	(char *)     		= linemodID;  
int (* linewidthP)	(int)   		= linewidthID;
int (* fillP)		(int)        		= fillID;     
int (* fontnameP)	(char *)    		= fontnameID; 
int (* fontsizeP)	(int)    		= fontsizeID; 
int (* rotateP)		(int, int, int)      	= rotateID;   
int (* eraseP)		(void)			= eraseID;    
int (* labelP)		(char *)       		= labelID;    
int (* alabelP)		(int, int, char *)      = alabelID;   
int (* arcP)		(int, int, int, int, int, int)         = arcID;      
int (* boxP)		(int, int, int, int)   	= boxID;      
int (* circleP)		(int, int, int)     	= circleID;   
int (* contP)		(int, float)	       	= contID;     
int (* dotP)		(int, int, int, int, char *)    = dotID;      
int (* pointP)		(int, int)       	= pointID;    
int (* lineP)		(int, int, int, int)   	= lineID;     
int (* moveP)		(int, float)	    	= moveID;     
