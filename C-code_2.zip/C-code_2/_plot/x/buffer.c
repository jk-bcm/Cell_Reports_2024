#include "plot.h"

XPoint	 Xpl_line_buffer [XPL_BUFFER_SIZE];
int	 Xpl_nlines  = 0;

XPoint   Xpl_point_buffer[XPL_BUFFER_SIZE];
int	 Xpl_npoints = 0;


void Xbuffer_point (int x, int y)
{  
  if (Xpl_npoints == XPL_BUFFER_SIZE) Xbuffer_flushpl();
  
  Xpl_point_buffer[Xpl_npoints].x = x;
  Xpl_point_buffer[Xpl_npoints].y = y;
  Xpl_npoints++;
}

void Xbuffer_cont (int x, int y)
{
  if (Xpl_nlines == XPL_BUFFER_SIZE) Xbuffer_flushpl();

  Xpl_line_buffer[Xpl_nlines].x = x;
  Xpl_line_buffer[Xpl_nlines].y = y;
  Xpl_nlines++;
}

void Xbuffer_move (int x, int y)
{
  Xbuffer_flushpl ();
  Xpl_line_buffer[0].x = x;
  Xpl_line_buffer[0].y = y;
}

void Xbuffer_flushpl ()
{
  XDrawPoints (xpl_window->dpy, xpl_window->win, xpl_window->gc, 
	       Xpl_point_buffer, Xpl_npoints, 
	       CoordModeOrigin);
  XDrawPoints (xpl_window->dpy, xpl_window->pix, xpl_window->gc, 
	       Xpl_point_buffer, Xpl_npoints, 
	       CoordModeOrigin);
  Xpl_npoints = 0;

  XDrawLines  (xpl_window->dpy, xpl_window->win, xpl_window->gc, 
	       Xpl_line_buffer, Xpl_nlines, 
	       CoordModeOrigin);
  XDrawLines  (xpl_window->dpy, xpl_window->pix, xpl_window->gc, 
	       Xpl_line_buffer, Xpl_nlines, 
	       CoordModeOrigin);
  Xpl_line_buffer[0] = Xpl_line_buffer[Xpl_nlines - 1];
  Xpl_nlines = 1;

  xpl_update();
}
