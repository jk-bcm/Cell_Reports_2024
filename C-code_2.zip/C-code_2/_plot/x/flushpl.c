#include "plot.h"

int flushplX ()
{
  Xbuffer_flushpl();
  fflush (NULL);
  xpl_update();
  return 0;
}

