
/* insert copyright here */

#include "plot.h"

extern int current_fontsize;		/* from fontsize.c */
extern char *current_font;		/* from fontname.c */

XFontStruct *current_font_struct = NULL;


void setfont ()
{
  char font_description[256];

  if (!current_font) {
    /* select default font */
    fontnameX("default");
  }

  sprintf (font_description, "*-%s-*-%d-*", current_font, current_fontsize);
  
  if (current_font_struct)
    XFreeFont (xpl_window->dpy, current_font_struct);
  current_font_struct = XLoadQueryFont (xpl_window->dpy, font_description);

  if (current_font_struct) 	/* font exists */
    XSetFont (xpl_window->dpy, xpl_window->gc, current_font_struct->fid);
    
}
  
