#include "plot.h"

int boxX             (int x0, int y0, int x1, int y1)
{
  return 0;
}
