#include "plot.h"

int dotX             (int x, int y, int dx, int n, char *pattern)
{
  switch (*(short *)pattern) {
  case ('c' * 256 + 'i'):
  case ('c' * 256 + 'r'):
  case ('p' * 256 + 'l'):
  case ('p' * 256 + 'o'):
    pointX (x, y);
  break;
  case ('s' * 256 + 't'):
    pointX (x, y);
  break;
  default:
  break;
  }
  return 0;
}

