#include "plot.h"

int linewidthX             (int w)
{
  XGCValues           	values;
  long                	value_mask = 0;

  flushplX();

  values.line_width = w;
  value_mask |= GCLineWidth;;
  XChangeGC (xpl_window->dpy, xpl_window->gc, value_mask, &values);

  return 0;
}

