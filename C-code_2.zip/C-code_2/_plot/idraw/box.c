/* this file is the box routine, which is a standard part of the plot(3)
   library. It draws a box given the coordinates of the diagonal corners, x0,y0
   and x1,y1 */

#include "plot.h"

int
boxID (x0, y0, x1, y1)
     int x0, y0, x1, y1;
{
  moveID (x0, y0);
  contID (x0, y1);
  contID (x1, y1);
  contID (x1, y0);
  contID (x0, y0);
  moveID (x1, y1);
  return 0;
}
