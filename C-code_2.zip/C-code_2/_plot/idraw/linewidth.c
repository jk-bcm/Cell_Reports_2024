#include "plot.h"

int
linewidthID (w)
    int w;
{
  draw_line();
  line_width = w;
  return 0;
}

