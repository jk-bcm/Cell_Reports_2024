#include "plot.h"

int flushplID ()
{
  draw_line();
  fflush (PSoutfile);
}
