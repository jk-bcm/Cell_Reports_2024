void Write_OutputFiles0();	/* print.c 	*/
void Write_OutputFiles0();	/* print.c 	*/
void Write_OutputFiles1();	/* print.c 	*/
void Write_OutputFiles2();	/* print.c	*/
void Write_OutputFiles3();	/* print.c	*/
void Ttest_macro4();		/* ttest.c	*/
void Print_Behav5();		/* printbehav.c	*/
void Ttest_macro6();		/* ttest.c	*/
void Interval7();		/* interval.c	*/
void Write_Targets8();		/* targets.c	*/
void Print_Behav9();		/* printbehav.c	*/

void CoupleLFP10();				/* lfp/lfp.c	*/
void PowerLFP11();				/* lfp/lfp.c	*/
void TimeSpikeLFP12();			/* lfp/lfp.c	*/
void CohSpikeLFP13();			/* lfp/lfp.c	*/
void PhasePairSpikeLFP14();		/* lfp/lfp.c	*/
void PowerTrialsLFP15();		/* lfp/lfp.c	*/
void TimeLFP16();				/* lfp/lfp.c	*/
void PhasePairLFP17();			/* lfp/lfp.c	*/
void CorLFP18();				/* lfp/lfp.c	*/
void CohLFP19();				/* lfp/lfp.c	*/
void PowBurstLFP211();			/* lfp/lfp.c	*/
void MatchPursuitLFP311();	    /* lfp/lfp.c	*/
void PowTraceLFP212();			/* lfp/lfp.c	*/
void CohgramSpikeLFP213();	    /* lfp/lfp.c	*/
void GrangerLFP215();           /* lfp/lfp.c    */
void EvokedLFP216();			/* lfp/lfp.c	*/

void Reference20();		/* coord/reference.c	*/

void RewardBasics30();		/* reward/basic.c	*/
void CodeByPrevAndCurrentClass31();	/* reward/basic.c	*/

void MemoryExtract40();		/* extract.c	*/
void MemoryOnOff41();		/* extract.c	*/
void MemoryTimes42();		/* extract.c	*/
void GetTuning43();		/* extract.c	*/
void SortByTarget44();      /* memory/sort.c */

void Success50();		/* success.c	*/
void Failure51();		/* failure.c	*/
void Success52();

void SacEndPoints60();		/* sac_endpt.c	*/
void Movement_times63(int FindSecondLimb);	/* movement.c	*/
void Movement_times65();	/* movement.c	*/

void FlashFields70();        	/* flash.c	*/
void Frame71();			/* flash.c	*/

void VestSensory80(char *file);	/* frame.c	*/
void VestMotor81(char *file);	/* frame.c	*/
void Frame82();		/* frame.c	*/
void FramePursue83();	/* pursue.c	*/
void Write_SacEndpts84(char *file);	  /* write_sac.c	*/
void Write_SpikeCounts85(char *file);	  /* write_sac.c	*/
void Write_SacDuration86(char *file);	  /* write_sac.c	*/
void ROC87();	        /* roc.c	*/
void ROC88();	        /* roc.c	*/
void ROC89();		/* roc.c	*/
void Trial_Info801();	/* trialinfo.c	*/

void BimanualTimes90(int FindSecondSac); /* latency.c        */
void BimanualTimes997(int FindSecondSac); /* latency.c        */

void TestArmVsEye100();	/* intent.c	*/
void JeffExportData101();	/* exportdata.c */
void TestDirections102();	/* direction.c	*/
void Test_yes103();		/* test.c	*/
void Test_no104();		/* test.c	*/
void GetBestClass105();	        /* getbestclass	*/
void SplitByEffector106(char *file);  /* split.c	*/
void SplitByClass107(char *file);	/* split.c	*/
void SplitByTrialType108(char *file);	/* split.c	*/
void SplitByClass1071(char *file);	/* split.c	*/
void SplitByTrialType1081(char *file);/* split.c	*/

void Write_SacEndpts110(char *file);	/* write_sac.c	*/
void Write_SacEndpts111(char *file);	/* write_sac.c	*/
void Write_SacEndpts1110(char *file);	/* write_sac.c	*/

void Print_Behav120();		/* printbehav.c		*/
void Print_Stim121();		/*printstim.c		*/
void Movement_Times123();	/*movement.c		*/
void GetBestClass125();	        /* getbestclass.c	*/
void Interval127();		/* interval.c		*/
void Print_Spikes128();		/* interval.c		*/
void FindSaccades129 (void );	/* findsac.c		*/

void Timing130();		/* timing.c		*/
void Target131();		/* target.c		*/
void SacTime132();		/* sactime.c		*/
void SacBehave133();		/* sacbehave.c		*/
void Errortype134();		/* errortype.c		*/

void Print_Spikes140();		/* print.c	*/
void Print_SpikeTimes141(int HeaderInfo);	/* print.c	*/
void Stats142();		/* print.c	*/
void Print_Info143();		/* print.c	*/
void Anova_macro144();		/* anova.c	*/
void TwoWayAnova_macro146();	/* anova.c	*/
void Print_EventExtract145();	/* print.c	*/
void Print_EventExtract147();	/* print.c	*/
void Print_EventExtractAll148();/* print.c	*/
void Check_Bounds150();		/* bounds.c	*/
void CountSpikes152();		/* print.c	*/
void Saccades155();		/* saccades.c	*/
void AnalogDataDump156();	/* print.c	*/
void PrintTouches161();		/* touch2.c	*/
void GetTrajectory162();	/* touch2.c	*/

void Write_Times400();		/* write_times.c*/
void Write_Times_tpj401();      /* write_times.c*/
void Write_Times_monk402();     /* write_times.c*/
void CueTarg_Times405();	/* write_times.c*/
void Targ_Times_tpj406();	/* write_times.c*/
void Targ_Times_monk407();      /* write_times.c*/
void MR_Event_File408();  	/* write_times.c*/
void PSEvents_409();  		/* write_times.c*/
void Blink410();		/* events.c	*/
void Saccade411();		/* events.c	*/
void Pulse412();		/* events.c	*/
void Sort420();  		/* sort.c*/
void MemorySaccades430(); 	/* memsac2009.c*/
void RunStartTime431(); 	/* memsac2009.c*/
void EventFileForMemory432(); 	/* memsac2009.c*/
void MemorySaccades433(); 	/* memsac2009.c*/
void Strabismus440(); 		/* strabismus.c	*/
void RunStartTime450(); 	/* memsac2011.c*/
void MemoryEvents451(); 	/* memsac2011.c*/
void MemoryEvents452(); 	/* memsac2011.c*/
void MemoryAccuracy453(); 	/* memsac2011.c*/
