/* FILE ad.h */
/* ******************************************************************** */

/* One AD unit is 1/20 of a degree.  There is a 2048 offset to ADs. 	*/

#define DEGtoAD(deg)    ((deg) * 20)                    /* Returns int  */
#define ADtoDEG(ad)     ((ad) / 20.)			/* Returns float*/
/* ******************************************************************** */

