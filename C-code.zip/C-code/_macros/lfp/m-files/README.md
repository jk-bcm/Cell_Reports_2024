These are matlab files that grab calls to analyze LFP data.

In most cases (unless otherwise noted), units are:

1. Time = ms
2. Sampleing rate = kHz
3. Frequencies, i.e., power analyses (Hz)

# Overhaul

As of July 2019, Chuck is cleaning up these files. 

**Verified to have identical output to original m-files:**

1. timeLFP
2. timeSpikeLFP
3. powerLFP
4. cohLFP
5. evokedLFP

**Cannot verify (for whatever reason), but done:**

1. phasePairLFP
2. corLFP
3. cohgramSpikeLFP.m
4. cohSpikeLFP.m (the mfiles were not working).
* phasePairSpikeLFP.m (the mfiles were not working).

**Filtering:** Filtering was being "done", but circumvented when loading LFPs
(filterSignal,m). There is also another file that filters the individual trials
for correlation and lfp coupling analyses (filterLfp.m). These should be
combined.

*Update:* Filtering is now implemented. Must pass value "pass_band" to load_lfps.

## Still need work

**Soon, for revision:**

* matchPursuitLFP.m


## Disabled list

These files have been moved to the directory "disabled_list" until they are
needed and can be fixed.

* matchPursuitLFP.m (should not stay here long).
* coupleLFP.m
* powBurstLFP.m
* powerTrialsLFP.m
* powTraceLFP.m

## Things Chuck would want to do if he had a bunch of time

1. Make band pass filtering quicker.
