/* FILE _macros/test.c */

#include "../Deffs.h"

/* ********************************************************************	*/
     /* Test; print name is see or don't see name */
     /*   (test all combinations against each other */

static int guts();
/* ********************************************************************	*/
/* ********************************************************************	*/

/* FUNCTION Test_yes103() */
/* FUNCTION Test_no104() */
	 /* Print unit number if any pair of trials is / isn't signif	*/
void Test_yes103() {
	if (guts())
	   fprintf(stderr, "%d.%d\n", UnitNumber_Header(), RunNumber_Header());
	}
void Test_no104() {
	if (guts() == 0)
	   fprintf(stderr, "%d.%d\n", UnitNumber_Header(), RunNumber_Header());
	}
/* ********************************************************************	*/

static int guts() {
	int Types   = Count_TrialTypes();
	int i, j;

	for (i=0; i<Types-1; i++)
	   for (j=i+1; j<Types; j++)	/* Int'val 1, type 0 v 1, 2 tails */
	      if (Ttest_On_Interval(1, i, j, 2) < .05)
	         return(1);
	return(0);
	}
/* ********************************************************************	*/

