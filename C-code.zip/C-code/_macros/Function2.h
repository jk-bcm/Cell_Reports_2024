/* FILE Functions2.h */
     /*  More functions for macros (e.g., -o70) */

/* event.c */   int AnyTargetEventExtract(int which, int occurrence);
/* ps.c */	void space(int x0, int y0, int x1, int y1);
/* input.c */	int    Read_Trial(int number);
/* ps.c */	void filledbox(int x0, int y0, int x1, int y1);
/* coord.c */	void Set_Dimensions_For_Coords(int row, int col);
/* title.c */	void  Do_Header_Title();
/* title.c */	void  Do_Class_Titles(int Output);
