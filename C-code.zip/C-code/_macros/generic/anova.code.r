# anova.code.r
options(echo=F)

#  Code to do 2-way anova

data <- matrix(	scan("anova.input", quiet=T), ncol=3, byrow=T, 
		dimnames=list(NULL, c("stack", "class", "spikes")))

Aov <- aov(spikes ~ stack * class, data.frame(data))

cat(round(summary(Aov)[[1]][1:3,5], dig=3), "\n")
