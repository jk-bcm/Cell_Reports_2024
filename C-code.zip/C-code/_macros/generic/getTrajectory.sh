#!/bin/sh

# matlab_exec=/usr/local/matlab/bin/matlab
matlab_exec=/usr/local/MATLAB/R2018a/bin/matlab
X="addpath('/data/code/grab/2009.washu/_macros/generic'); getTrajectory(${1})"
echo ${X}
echo ${X} | ${matlab_exec} -nojvm -nodisplay -nosplash
#rm matlab_command_${1}.m
