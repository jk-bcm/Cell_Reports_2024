/* FILE _macros/stimulate/findsac.c */
/* ********************************************************************	*/

/*  originally based on code from Dustin Heldman's Macros 63, 64	*/
/*  reports the time of a the first saccade in the interval		*/ 
/*  i think this macro is obsolete - i now use larry's macro 155	*/

/* ********************************************************************	*/
#include "../Deffs.h"
#include "../../event.h"
/* ********************************************************************	*/

void FindSaccades129 (void )
{
	FILE *file;
   	char Name[80];
	sprintf(Name, "BreakTrials_%d.%d",
		UnitNumber_Header(), RunNumber_Header());
   	file = fopen(Name, (MACRO_APPENDS)?"a":"w");
   	if (file==NULL) {
      	   fprintf(stderr, "Err opening %s", Name);
      	   Exit("", "Write_OutputFiles0()");
      	   }

	/* intervals and alignment set on the command line */
	int start_time = Get_Interval_Begin(1);
	int stop_time = Get_Interval_End(1);

	Rewind_InputFile();		/* For consistent unit,run#	*/

	/* Loop thru data: */
	while (Read_Next_Trial(WITH_DATA)) {
	int sactime=0;

	int currenttime = start_time - 40;
        while(currenttime < stop_time){
	    int storetime = currenttime;
	    fprintf(stderr, "DIAG: See note in macro!!\n");
/* LHS 2007-8-30:  I'm pretty sure that the time parameter in the
 * Get_Saccade_Time() call is in the wrong format.  It should be stack time,
 * but this is interval time!  Fortunately, this macro wasn't used, I think.
 */
	    currenttime = Get_Saccade_Time(1,1,currenttime+40,0);
	    if ((currenttime != FAIL) && (currenttime < stop_time)) {
		  sactime = currenttime - start_time;
		  break;	    /* found one! */
	    } else {
		currenttime = storetime + 200;
	    }
	  }
	if (sactime > 0 )
	    fprintf(file,"-x%d(%d) ",TrialNumber_Input(),sactime);
    }
	fprintf(file,"\n");
	fclose(file);
}
