/* FILE Deffs.h */
     /* Deffs.h file for macros */

#include <stdio.h>
#include "../anal.h"
#include "Function.h"
#include "../config.h"
#include <math.h>
#include <fcntl.h>                                      /* Open/close   */
#include <sys/types.h>                                  /* stat()       */
#include <sys/stat.h>                                   /* stat()       */

#  define	TIME		0	/* For StackExtract 'which'	*/
#  define	ONE		1
#  define	TWO		2
#  define	THREE		3
#  define	TYPE		-1

/* MISC CONSTANTS: */

#  define	FAIL		-99999	/* Used especially by StackExt()*/
#  define	YES		1
#  define	NO		0
#  define	ON		1
#  define	OFF		0

#define VAR(s,s2,n)	(fabs((s2)-(s)*((double)(s))/(n)) / ((n)-1))
#define SD(s, s2, n)	((float) sqrt(VAR(s,s2,n)))
#define SE(s, s2, n)	((float) sqrt(VAR(s,s2,n)/(n)))

#define Min(a,b)	( ((a) > (b)) ? (b) : (a) )
#define Max(a,b)	( ((a) > (b)) ? (a) : (b) )
/* *******************************************************************	*/

#undef NULL
#define NULL ((void *) 0)
