/* FILE xplot */
     /* Calls for xpot */

SetLineWidth(i) { }			/* Not supported by xplot	*/
