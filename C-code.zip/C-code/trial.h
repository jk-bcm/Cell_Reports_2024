/* FILE trial.h */
     /* Trial type structure */

static int CountTypes;

static struct TRIAL_TYPE {	/* All variables that can define a trial*/
	int targ1;
	int targ2;
	int targ3;
	int head;
	int where;
	int veloc;
	int accel;
	int table;
	int stack;
	int cell;
	int col;				/* 1 to cols		*/
	int row;				/* 1 to rows		*/
	int n;
	int order;				/* Where in data file	*/
	char stackname[40];
	} TrialType[MAX_FIGS];			/* Describe a type	*/
